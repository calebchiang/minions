package com.bcit.lab4calebchiang

interface Repeatable {
    fun repeat(int: Int, listener: MissionListener): Unit
}