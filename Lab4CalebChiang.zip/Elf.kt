package com.bcit.lab4calebchiang

class Elf : Minion() {
    override var race = "Elf"
    override var baseHealth = 2
    override var baseSpeed = 8
    override var backpackSize = 3
    override var catchphrase = "My arrows never miss!"
}