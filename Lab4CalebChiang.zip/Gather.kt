package com.bcit.lab4calebchiang

import kotlin.random.Random

class Gather(minion: Minion) : Mission(minion), Repeatable {
    override fun determineMissionTime(): Int {
        val randomNumber = Random.nextInt(0, 5)
        return (minion.backpackSize + minion.baseSpeed) * randomNumber
    }

    override fun reward(time: Int): String {
        return when (time) {
            in 10..21 -> "bronze"
            in 22..33 -> "silver"
            in 34..50 -> "gold"
            else -> "nothing"
        }
    }

    override fun repeat(int: Int, listener: MissionListener) {
        repeat(int) {
            start(listener)
        }
    }
}