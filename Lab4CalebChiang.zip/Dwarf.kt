package com.bcit.lab4calebchiang

class Dwarf : Minion() {
    override var race = "Dwarf"
    override var baseHealth = 8
    override var baseSpeed = 2
    override var backpackSize = 8
    override var catchphrase = "Wheres' me trusty ol hammer"
}