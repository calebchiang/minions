package com.bcit.lab4calebchiang

class Human : Minion() {
    override var race = "Human"
    override var baseHealth = 5
    override var baseSpeed = 5
    override var backpackSize = 5
    override var catchphrase = "Ready for anything!"
}